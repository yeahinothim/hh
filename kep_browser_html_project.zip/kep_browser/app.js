const $ = (id) => document.getElementById(id);

let bookmarks = JSON.parse(localStorage.getItem("kepBookmarks") || "[]");
let historyItems = JSON.parse(localStorage.getItem("kepHistory") || "[]");
let currentUrl = "";

function save() {
  localStorage.setItem("kepBookmarks", JSON.stringify(bookmarks));
  localStorage.setItem("kepHistory", JSON.stringify(historyItems));
}

function normalizeAddress(value) {
  const input = value.trim();
  if (!input) return "";
  if (/^https?:\/\//i.test(input)) return input;
  if (/^[\w-]+(\.[\w-]+)+([/?#].*)?$/i.test(input)) return "https://" + input;
  return "https://www.google.com/search?q=" + encodeURIComponent(input);
}

function openAddress(value) {
  const url = normalizeAddress(value);
  if (!url) return;
  currentUrl = url;
  historyItems = [{ url, date: Date.now() }, ...historyItems.filter(item => item.url !== url)].slice(0, 30);
  save();
  render();
  $("homeView").hidden = true;
  $("tabView").hidden = false;
  $("tabTitle").textContent = "Ready to visit";
  $("tabUrl").textContent = url;
  window.open(url, "_blank", "noopener");
  toast("Opened in a new Safari tab");
  setActive("tabsBtn");
}

function toast(message) {
  $("toast").textContent = message;
  $("toast").classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => $("toast").classList.remove("show"), 1900);
}

function setActive(id) {
  document.querySelectorAll(".nav-btn").forEach(btn => btn.classList.toggle("active", btn.id === id));
}

function showHome() {
  $("homeView").hidden = false;
  $("tabView").hidden = true;
  setActive("homeBtn");
}

function makeSavedItem(item, type) {
  const row = document.createElement("div");
  row.className = "saved-item";
  const main = document.createElement("button");
  main.className = "saved-main";
  main.style.cssText = "background:transparent;border:0;text-align:left;padding:0;min-width:0";
  const title = document.createElement("span");
  title.className = "saved-title";
  title.textContent = item.title || item.url.replace(/^https?:\/\//, "");
  const url = document.createElement("span");
  url.className = "saved-url";
  url.textContent = item.url;
  main.append(title, url);
  main.addEventListener("click", () => openAddress(item.url));
  row.append(main);
  if (type === "bookmark") {
    const remove = document.createElement("button");
    remove.textContent = "✕";
    remove.setAttribute("aria-label", "Remove bookmark");
    remove.addEventListener("click", () => {
      bookmarks = bookmarks.filter(x => x.url !== item.url);
      save(); render();
    });
    row.append(remove);
  }
  return row;
}

function render() {
  const bookmarkBox = $("bookmarks");
  const historyBox = $("history");
  bookmarkBox.replaceChildren();
  historyBox.replaceChildren();

  if (!bookmarks.length) bookmarkBox.innerHTML = '<p class="empty">No bookmarks yet. Visit a site and save it.</p>';
  bookmarks.forEach(item => bookmarkBox.append(makeSavedItem(item, "bookmark")));

  if (!historyItems.length) historyBox.innerHTML = '<p class="empty">Nothing visited yet.</p>';
  historyItems.slice(0, 8).forEach(item => historyBox.append(makeSavedItem(item, "history")));
}

$("searchForm").addEventListener("submit", event => {
  event.preventDefault();
  openAddress($("addressInput").value);
  $("addressInput").blur();
});

document.querySelectorAll(".quick-link").forEach(button => {
  button.addEventListener("click", () => openAddress(button.dataset.url));
});

$("newTabBtn").addEventListener("click", () => {
  $("addressInput").value = "";
  showHome();
  $("addressInput").focus();
});

$("homeBtn").addEventListener("click", showHome);
$("tabsBtn").addEventListener("click", () => {
  if (currentUrl) {
    $("homeView").hidden = true;
    $("tabView").hidden = false;
    $("tabUrl").textContent = currentUrl;
    $("tabTitle").textContent = "Current tab";
  } else showHome();
  setActive("tabsBtn");
});
$("bookmarksBtn").addEventListener("click", () => {
  showHome();
  $("bookmarks").scrollIntoView({ behavior: "smooth", block: "center" });
  setActive("bookmarksBtn");
});
$("historyBtn").addEventListener("click", () => {
  showHome();
  $("history").scrollIntoView({ behavior: "smooth", block: "center" });
  setActive("historyBtn");
});
$("clearBookmarksBtn").addEventListener("click", () => {
  bookmarks = []; save(); render(); toast("Bookmarks cleared");
});
$("clearHistoryBtn").addEventListener("click", () => {
  historyItems = []; save(); render(); toast("History cleared");
});
$("reopenBtn").addEventListener("click", () => currentUrl && window.open(currentUrl, "_blank", "noopener"));

let holdTimer;
$("tabUrl").addEventListener("click", async () => {
  if (!currentUrl) return;
  try {
    await navigator.clipboard.writeText(currentUrl);
    toast("Address copied");
  } catch {
    toast("Long-press the address to copy it");
  }
});

render();
